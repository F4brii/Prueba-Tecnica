export class Area{
    id?: number;
    name: string;
    description: string;
}